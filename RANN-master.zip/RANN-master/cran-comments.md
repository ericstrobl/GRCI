## Changes since last release
Removing register keyword from C++ library to address CRAN build issue.

## Test environments
* local OS X install, R 3.5.1
* ubuntu 14.04 (on travis-ci), R 3.5.0
* win-builder (devel)

No checks gave any ERRORs, WARNINGs or NOTEs.

Reverse dependency checks did not identify any changes for the worse.
